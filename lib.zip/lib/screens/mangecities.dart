import 'package:flutter/material.dart';

class ManageCity extends StatelessWidget {
  const ManageCity({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold();
  }
}