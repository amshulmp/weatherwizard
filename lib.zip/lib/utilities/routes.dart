class Routes{
static String splash="/splash";
static String home="/home";
static String city="/city";
}