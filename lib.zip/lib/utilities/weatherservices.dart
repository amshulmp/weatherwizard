import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';

class WeatherProvider extends ChangeNotifier {
  late Position _currentPosition; 
  WeatherData data = WeatherData(
    temperaturemin: "loading",
    city: "loading",
    weatherType: "loading",
    wind: "loading",
   
    humidity: "loading",
    feelslike: "loading",
     temperature: "loading",
      temperatuemax: "loading", sealevel: "loading",
  );

 
  Position get currentPosition => _currentPosition;

  Future<void> getCurrentLocation() async {
    _currentPosition = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
    await getWeatherData();
  }

  Future<void> getWeatherData() async {
    final response = await http.get(Uri.parse(
        "https://api.openweathermap.org/data/2.5/weather?lat=${_currentPosition.latitude}&lon=${_currentPosition.longitude}&appid=cd6516b46fed84bc7975eeef43d2604d"));

    if (response.statusCode == 200) {
      final weatherData = json.decode(response.body);
   
      data = WeatherData(
        city: weatherData['name'],
        weatherType: weatherData['weather'][0]['main'],
        temperaturemin: (weatherData['main']["temp_min"] - 273.15),
        humidity: weatherData['main']['humidity'],
         wind: weatherData['wind']['speed'],
          temperature:(weatherData['main']["temp"] - 273.15),
           temperatuemax: (weatherData['main']["temp_max"] - 273.15),
          
            feelslike: weatherData['main']["feels_like"] - 273.15,
             sealevel: weatherData['main']["sea_level"], 
      );
      notifyListeners();
    } else {
      throw Exception('Failed to load weather data');
    }
  }
}

class WeatherData {
  final dynamic temperature;
  final dynamic temperaturemin;
  final dynamic city;
  final dynamic weatherType;
  final dynamic wind;
  final dynamic humidity;
  final dynamic temperatuemax;
  final dynamic feelslike;
   final dynamic sealevel;

  WeatherData( {
    required this.temperature,
    required this.temperaturemin,
    required this.city,
    required this.weatherType,
    required this.wind,
  required this.sealevel,
    required this.humidity,
    required this.temperatuemax,
    required this.feelslike,
  });
}
